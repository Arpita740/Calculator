package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.calc.R;

public class MainActivity extends AppCompatActivity {
    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btna,btneq,btns,btnm,btnd,btnc;
    EditText editText;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn0=(Button)findViewById(R.id.btn0);
        btn1=(Button)findViewById(R.id.btn1);
        btn2=(Button)findViewById(R.id.btn2);
        btn3=(Button)findViewById(R.id.btn3 );
        btn4=(Button)findViewById(R.id.btn4 );
        btn5=(Button)findViewById(R.id.btn5 );
        btn6=(Button)findViewById(R.id.btn6 );
        btn7=(Button)findViewById(R.id.btn7 );
        btn8=(Button)findViewById(R.id.btn8 );
        btn9=(Button)findViewById(R.id.btn9);
        btna=(Button)findViewById(R.id.btna );
        btns =(Button)findViewById(R.id.btns);
        btnm=(Button)findViewById(R.id.btnm );
        btnd=(Button)findViewById(R.id.btnd);
        btnc=(Button)findViewById(R.id.btnc);
        btneq =(Button)findViewById(R.id.btneq );
        editText = (EditText) findViewById(R.id.editText);
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("0");
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("3");
            }
        });
        btn4 .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("4");
            }
        });
        btn5 .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("5");
            }
        });
        btn6 .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("6");
            }
        });
        btn7 .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("7");
            }
        });
        btn8 .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("8");
            }
        });
        btn9 .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("9");
            }
        });
        btna .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("+");
            }
        });
        btns .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("-");
            }
        });
        btnm .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("*");
            }
        });
        btnd .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.append("/");
            }
        });
        btnc .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.setText("");
            }
        });
        btneq .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = editText.getText().toString();
                if(data.contains("-")){
                    String operand[]=data.split("-");
                    Double op1= Double.parseDouble(operand[0]);
                    Double op2= Double.parseDouble(operand[1]);
                    Double result = op1-op2;
                    editText.setText(String.valueOf(result));
                } else if (data.contains("+")) {
                    String operand[]=data.split("[+]");
                    Double op1= Double.parseDouble(operand[0]);
                    Double op2= Double.parseDouble(operand[1]);
                    Double result = op1+op2;
                    editText.setText(String.valueOf(result));
                }
                else if(data.contains("/")){
                    String operand[]=data.split("/");
                    Double op1= Double.parseDouble(operand[0]);
                    Double op2= Double.parseDouble(operand[1]);
                    Double result = op1/op2;
                    editText.setText(String.valueOf(result));
                }
                else
                {
                    String operand[]=data.split("[*]");
                    Double op1= Double.parseDouble(operand[0]);
                    Double op2= Double.parseDouble(operand[1]);
                    Double result = op1*op2;
                    editText.setText(String.valueOf(result));
                }
            }
        });
    }
}